#ifndef INPUT_H
#define INPUT_H
float keyboard_to_freq(char sound, char key);
#endif