/*
    Test Suit for Arduino Music Player
*/ 
void scale_test();
void twinkle();
