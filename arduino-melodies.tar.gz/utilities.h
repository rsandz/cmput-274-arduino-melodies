#ifndef UTILS_H
#define UTILS_H
void convert_to_period(float beat[], int bpm, int array_size);
char get_key();
#endif
